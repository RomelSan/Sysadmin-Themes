
Invoke-Pester $PSScriptRoot
